library(MfUSampler)
levels(Arthritis$Treatment)=c(0,1)
levels(Arthritis$Sex)=c(0,1)
p1<-function(x,a) plogis(a[1] + sum(a[3:5]*x[1:3]))
p2<-function(x,a) plogis(a[2] + sum(a[3:5]*x[1:3]))-plogis(a[1] + sum(a[3:5]*x[1:3]))
p3<-function(x,a) plogis(a[2] + sum(a[3:5]*x[1:3]),lower.tail = F)
x=cbind(as.numeric(Arthritis$Treatment),as.numeric(Arthritis$Sex),Arthritis$Age)
Y= cbind(as.numeric(Arthritis$Improved=="None"),as.numeric(Arthritis$Improved=="Some"),as.numeric(Arthritis$Improved=="Marked"))
l = function(a){ #likelihood of the data
S = sapply(1:84, function(i) sum(Y[i,]*log(c(p1(x[i,],a),p2(x[i,],a),p3(x[i,],a)))))
return(exp(sum(S)))
}
prio<-function(a) prod(c(dnorm(a[1],1,2),dnorm(a[2],1,2),dnorm(a[3],-2,2),dnorm(a[4],2,2))) # prior
log_post<-function(a) log(l(a)*prio(a))
MfUSampler::MfU.Sample.Run(init,log_post,nsmp = 500)
