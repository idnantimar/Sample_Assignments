x = runif(100,-2,3)
A=c(-0.5,2,1)
p1<-function(x,a) plogis(a[1] + (a[3]*x))
p2<-function(x,a) plogis(a[2] + (a[3]*x))-plogis(a[1] + (a[3]*x))
p3<-function(x,a) plogis(a[2] + (a[3]*x),lower.tail = F)
constr<-function(a) a[1]-a[2] 
init = c(0,1,0)
xn100N500 = x
PARn100N500 = sapply(1:500, function(t) {
  Y=t(sapply(1:100, function(i) {
    r = rmultinom(1,1,c(p1(x[i],A),p2(x[i],A),p3(x[i],A)))
    return(c(r,(which(r==1))))
    }))
 
  neg_l = function(a){
    S = sapply(1:100, function(i) sum(Y[i,1:3]*log(c(p1(x[i],a),p2(x[i],a),p3(x[i],a)))))
    return(-1*sum(S))
  }
  
  con = (constrOptim(theta = init,f = neg_l,ui= c(-1,1,0),ci=0,grad = NULL))$par
  uncon = (optim(init,neg_l))$par
  return(c(con,uncon,neg_l(con),neg_l(uncon)))
  
}
)

xyplot(factor(Y[,4])~x,xlab="x",ylab="response",main="n=60,realization 2")

PAR=PARn25N1000
dns4<-function(x,m,v) dnorm(x,m,sqrt(v))

dns=function(x) dns4(x,mean(PAR[1,]),var(PAR[1,]))
densityplot((PAR[1,]),xlab="alpha1")+
  layer(panel.curve(dns,lty=2))+
  layer(panel.abline(v=A[1],col="red"))
dns=function(x) dns4(x,mean(PAR[2,]),var(PAR[2,]))
densityplot((PAR[2,]),xlab="alpha2")+
  layer(panel.curve(dns,lty=2))+
  layer(panel.abline(v=A[2],col="red"))
dns=function(x) dns4(x,mean(PAR[3,]),var(PAR[3,]))
densityplot((PAR[3,]),xlab="beta")+
  layer(panel.curve(dns,lty=2))+
  layer(panel.abline(v=A[3],col="red"))


plot(PAR[1,]-PAR[4,],type="h",ylab="con.-uncon.",main="alpha1")
plot(PAR[2,]-PAR[5,],type="h",ylab="con.-uncon.",main="alpha2")
plot(PAR[3,]-PAR[6,],type="h",ylab="con.-uncon.",main="beta")


plot(PAR[5,]-PAR[4,],type="h",ylab="uncon. (alpha2-alpha1)",col="darkgrey")

